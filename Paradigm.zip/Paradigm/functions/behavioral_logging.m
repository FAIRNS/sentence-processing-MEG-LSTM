function T = behavioral_logging(curr_violIndex, curr_wrong_location, curr_ok_location, Response, T)

if curr_violIndex == 1
    %% The subjects need to choose "Wrong"
    % True-positive left side
    if strcmp(curr_wrong_location,'left') && strcmp(Response,'Left')
        T.subject_response{trial} = 1;
        T.RT{trial}               = num2str(firstPress(handles.Key)- panel_onset);
        T.Behavioral{trial}       = 'TP';
        T.Behavioral_index{trial} = 1;
        % True-positive right side
    elseif strcmp(curr_wrong_location,'right') && strcmp(Response,'Right')
        T.subject_response{trial} = 1;
        T.RT{trial}               = num2str(firstPress(handles.Key)- panel_onset);
        T.Behavioral{trial}       = 'TP';
        T.Behavioral_index{trial} = 1;
        % False-positive right side
    elseif strcmp(curr_wrong_location,'right') && strcmp(Response,'Left')
        T.subject_response{trial} = 0;
        T.RT{trial}               = num2str(firstPress(handles.Key)- panel_onset);
        T.Behavioral{trial}       = 'FN';
        T.Behavioral_index{trial} = 2;
        % False-positive left side
    elseif strcmp(curr_wrong_location,'left') && strcmp(Response,'Right')
        T.subject_response{trial} = 0;
        T.RT{trial}               = num2str(firstPress(handles.Key)- panel_onset);
        T.Behavioral{trial}       = 'FN';
        T.Behavioral_index{trial} = 2;
    end
else
    %% The subjects need to choose "OK"
    % True-negative left
    if strcmp(curr_ok_location,'left') && strcmp(Response,'Left')
        T.subject_response{trial} = 0;
        T.RT{trial}               = num2str(firstPress(handles.Key)-panel_onset);
        T.Behavioral{trial}       = 'TN';
        T.Behavioral_index{trial} = 3;
        % True-negative right
    elseif strcmp(curr_ok_location,'right') && strcmp(Response,'Right')
        T.subject_response{trial} = 0;
        T.RT{trial}               = num2str(firstPress(handles.Key)-panel_onset);
        T.Behavioral{trial}       = 'TN';
        T.Behavioral_index{trial} = 3;
        % False-negative left
    elseif strcmp(curr_ok_location,'left') && strcmp(Response,'Right')
        T.subject_response{trial} = 1;
        T.RT{trial}               = num2str(firstPress(handles.Key)-panel_onset);
        T.Behavioral{trial}       = 'FP';
        T.Behavioral_index{trial} = 4;
        % False-negative right
    elseif strcmp(curr_ok_location,'right') && strcmp(Response,'Left')
        T.subject_response{trial} = 1;
        T.RT{trial}               = num2str(firstPress(handles.Key)-panel_onset);
        T.Behavioral{trial}       = 'FP';
        T.Behavioral_index{trial} = 4;
    end
end
