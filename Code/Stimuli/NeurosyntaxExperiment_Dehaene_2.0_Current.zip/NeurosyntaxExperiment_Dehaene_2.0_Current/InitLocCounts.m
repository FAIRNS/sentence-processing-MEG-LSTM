%InitLocCounts    

Loc.Counts.PPLoc=zeros(3,1);
Loc.Counts.TransAnim=zeros(4,1);
Loc.Counts.InTransAnimAndVerb=zeros(4,1);
Loc.Counts.PPAnim=zeros(2,1);

Loc.Counts.NPToLengthen=zeros(4,1);

Loc.Counts.SingPlural=zeros(3,2);
Loc.Counts.NumOrNoNum=zeros(2,2);
Loc.Counts.DefType=zeros(3,3);
Loc.Counts.ThisVsThat=zeros(3,2);
