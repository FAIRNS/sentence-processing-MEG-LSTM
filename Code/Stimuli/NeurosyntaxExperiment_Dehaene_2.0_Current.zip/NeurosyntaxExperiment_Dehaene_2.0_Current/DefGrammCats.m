% DefGrammCats   

%                1           2           3           4         5          6        7         8        9           10  
GrammCats = {'_N_P0',  '_VT_V_P0',  '_VI_V_P0',  '_A_P0',  '_ADV_P0',  '_D_P0',  '_T_P0',  '_NUM',  '_P_P0',  '_INTENSIF'};
DemonRootAdjust={'this','that','these','those'};    % fix these demonstratives to have a common root of 'this' (as they should have)                   

