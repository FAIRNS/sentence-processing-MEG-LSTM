%DefContentCatList.m

ContentCatList={'_N_P0'  '_V_P0'  '_A_P0'   '_ADV_P0'  '_EMOTION_A_P0'  '_PHYSICAL_A_P0'};