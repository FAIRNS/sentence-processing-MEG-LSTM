%LoadLabConflicts.m

LabConflicts={ {'$UNFRIENDLY','$FRIENDLY'};
               {'$MASC', '$FEMI' '$INANIMATE'};
               {'$LARGE_NOUN','$SMALL_NOUN'};
               {'$SINGULAR'  '$PLURAL'};
};

