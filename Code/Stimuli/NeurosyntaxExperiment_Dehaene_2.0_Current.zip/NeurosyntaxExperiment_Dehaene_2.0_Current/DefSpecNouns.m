%DefSpecNouns.m

SpecNouns={'waiter','waitress','actor','actress'};
