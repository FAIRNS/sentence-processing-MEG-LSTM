BlockDur=toc;        
tic
save(outfile,'BlockDur','BlockPauseDur','-append')
