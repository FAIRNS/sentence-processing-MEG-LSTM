Screen('TextStyle',window, 0);
Screen('TextSize',window, fs_PressEnter);  %     round(24*fontscaling));
DrawFormattedText(window,'Press any key to close the experiment','center',ypix*.9,black);