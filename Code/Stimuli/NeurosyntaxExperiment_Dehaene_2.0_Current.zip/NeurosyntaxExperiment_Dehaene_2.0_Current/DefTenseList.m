%DefTenseList.m

TenseList={'#future'  '#perfect'  '#present'  '#past'};