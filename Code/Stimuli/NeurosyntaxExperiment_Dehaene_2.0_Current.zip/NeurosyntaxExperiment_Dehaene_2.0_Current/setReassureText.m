switch curBlockType
    case 1
        ReassureText='It''s OK if you make a mistake or miss a trial. Just do your best on every trial.';  
    case 2
        ReassureText='It''s OK if you make a mistake or miss a trial. Just do your best on every trial.';
    case 3
        ReassureText='It''s OK if you make a mistake or miss a trial.\nThis task can be difficult. Just do your best on every trial.';
end
