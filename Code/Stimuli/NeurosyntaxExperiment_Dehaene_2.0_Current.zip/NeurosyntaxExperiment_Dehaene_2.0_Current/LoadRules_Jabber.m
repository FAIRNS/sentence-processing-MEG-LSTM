global language;

switch language
    case 1 % English
    LoadRules_English_NonContent;
    JabberwockyWords_English;
    case 2 % French
    LoadRules_French;
    case 3 % Dutch
    LoadRules_Dutch;
    case 4 % Spanish
    LoadRules_Spanish;
end
 
    