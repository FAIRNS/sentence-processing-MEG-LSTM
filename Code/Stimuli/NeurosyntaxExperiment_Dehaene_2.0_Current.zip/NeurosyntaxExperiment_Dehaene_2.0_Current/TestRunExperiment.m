% TestRunExperiment.m

nloops=100;

for il=1:nloops
    RunExperiment() % meant to be doen with the turning off of PsychTOolBox set to 1...    
end
