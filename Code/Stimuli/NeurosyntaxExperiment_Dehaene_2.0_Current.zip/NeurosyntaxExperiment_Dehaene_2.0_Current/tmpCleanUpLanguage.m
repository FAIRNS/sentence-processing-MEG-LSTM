%tmpCleanUpLanguage.m

clear all

load('SampleGeneratedSentences_Main')
clear language
save('SampleGeneratedSentences_Main')

load('SampleGeneratedSentences_Loc')
clear language
save('SampleGeneratedSentences_Loc')

load('SampleGeneratedSentences_Jab')
clear language
save('SampleGeneratedSentences_Jab')



