Screen('TextSize',window, fs_Feedback1);
DrawFormattedText(window,fbtext1,'center',ypix*.6,fbcol);