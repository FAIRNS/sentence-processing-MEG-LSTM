
for isent = 1:nsentences
    PrintReadableSentence(surface{isent});
    %PrintShortenedType(SentInfo(isent).Probe);
    PrintReadableSentence(shortened{isent});
    disp('************************************');
end





    