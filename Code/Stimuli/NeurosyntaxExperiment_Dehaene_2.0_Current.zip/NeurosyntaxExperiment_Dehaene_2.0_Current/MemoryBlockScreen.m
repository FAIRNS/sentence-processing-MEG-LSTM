Screen('TextSize',window, fs_BlockTitle);  %     round(24*fontscaling));
Screen('TextStyle',window, 1);  %%% 0 = normal

DrawFormattedText(window, 'Memory Block', 'center','center',black,wrapat,[],[],vSpacing);