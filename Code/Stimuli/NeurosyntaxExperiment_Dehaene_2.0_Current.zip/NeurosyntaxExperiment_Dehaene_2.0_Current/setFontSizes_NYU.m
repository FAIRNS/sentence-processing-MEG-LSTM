% setFontSizes_NYU.m    

fs_BlockTitle=36;
fs_Loading=22;
fs_PressEnter=18;
fs_TrainText=30;
wrapat=65; % Determines the number of characters before starting a new line when displaying the training text    
vSpacing=1.5;

fs_Stim=36;
fs_Ques=36;
fs_Feedback1=36;
fs_Feedback2=36;