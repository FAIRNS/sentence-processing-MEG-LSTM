function GenLab=FindLabType_Rec(d,inode,LabType)

% searches later nodes in the tree for the existence of any one lab from the list LabType in the children labels     

%  changing the case changes   