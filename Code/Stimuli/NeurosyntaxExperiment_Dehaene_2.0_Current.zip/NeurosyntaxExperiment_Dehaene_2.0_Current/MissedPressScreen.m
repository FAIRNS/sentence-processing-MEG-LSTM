Screen('TextSize',window, fs_BlockTitle);  %     round(24*fontscaling));
Screen('TextStyle',window, 1);  %%% 0 = normal

DrawFormattedText(window, 'Missed Press', 'center','center',red,wrapat,[],[],vSpacing);