Screen('TextSize',window, fs_TrainText);  %     round(24*fontscaling));
DrawFormattedText(window, 'Thank you for all your effort', 'center',ypix*.7,black,wrapat,[],[],vSpacing);