% setparameters_NYU.m   

language=1;     %1=English; 2=French; 3=Dutch; 4=Spanish     

escapekey = {'esc','ESCAPE'};
SameKey='p';
DiffKey='q';

TTLsending = 0;  %%% send TTL signals to parallel port 888
Photodiode = true;

setFontSizes_NYU
%setdelays_debug
setdelays_NYU

PlaceStr='NYU';

% this should be the path to the directory Presentation works from  
savedir = '?';  
% Example of what to write above to save time:  
savedir = 'C:\Users\Matt\Desktop\Neurosyntax2.0_Package_NYU\Neurosyntax2.0_Presentation';
  
