Screen('TextStyle',window, 0);
Screen('TextSize',window, fs_PressEnter);  %     round(24*fontscaling));
DrawFormattedText(window,'(press enter)','center',ypix*.95,black);