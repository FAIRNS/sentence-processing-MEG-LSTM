

Verbs={'arrive','depart','appear','explode','fall','frown','smile'};
AvoidPreps_wVerb={{'in','on'},{'in','on'},{'in'},{'on'},{'in','on'},{'on'},{'on'}};




