%%%%% additional knowledge of conjugation
%global language
switch language
    case 1 % English
    LoadLexicon_English;
    case 2 % French
    LoadLexicon_French;
    case 3 %Dutch
    LoadLexicon_Dutch;
    case 4 % Spanish
    LoadLexicon_Spanish;
end
