% DefGrammCategs   

GrammCategs = {'_N_P0',  '_VT_V_P0',  '_VI_V_P0',  '_A_P0',  '_ADV_P0',  'D_P0',  '_T_P0',  '_NUM',  '_P_P0',  '_INTENSIF'};

