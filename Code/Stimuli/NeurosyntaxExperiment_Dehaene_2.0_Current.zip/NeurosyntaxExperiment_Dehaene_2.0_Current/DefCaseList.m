%DefCaseList.m

CaseList={'$NOMINATIVE'  '$ACCUSATIVE'  '$LOCATIVE'};