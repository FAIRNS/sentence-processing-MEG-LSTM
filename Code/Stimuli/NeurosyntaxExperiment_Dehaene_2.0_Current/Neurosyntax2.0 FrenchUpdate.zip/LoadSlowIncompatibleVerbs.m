switch language
    case 1
        AvoidVerbs={'thrill','terrify','vanish','explode','fall','appear'};
    case 2
        AvoidVerbs={'thrill','terrify','vanish','explode','fall','appear'};
end